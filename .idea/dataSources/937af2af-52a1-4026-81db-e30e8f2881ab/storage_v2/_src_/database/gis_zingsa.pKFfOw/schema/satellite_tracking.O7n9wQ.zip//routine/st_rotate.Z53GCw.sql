create function st_rotate(satellite_tracking.geometry, double precision, satellite_tracking.geometry) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT satellite_tracking.ST_Affine($1,  cos($2), -sin($2), 0,  sin($2),  cos($2), 0, 0, 0, 1, satellite_tracking.ST_X($3) - cos($2) * satellite_tracking.ST_X($3) + sin($2) * satellite_tracking.ST_Y($3), satellite_tracking.ST_Y($3) - sin($2) * satellite_tracking.ST_X($3) - cos($2) * satellite_tracking.ST_Y($3), 0)$$;

comment on function st_rotate(satellite_tracking.geometry, double precision, satellite_tracking.geometry) is 'args: geomA, rotRadians, pointOrigin - Rotates a geometry about an origin point.';

alter function st_rotate(satellite_tracking.geometry, double precision, satellite_tracking.geometry) owner to postgres;

