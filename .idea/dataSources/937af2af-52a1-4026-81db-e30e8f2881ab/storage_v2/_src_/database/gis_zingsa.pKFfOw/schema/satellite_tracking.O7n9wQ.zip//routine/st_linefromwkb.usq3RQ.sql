create function st_linefromwkb(bytea) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN satellite_tracking.geometrytype(satellite_tracking.ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN satellite_tracking.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_linefromwkb(bytea) owner to postgres;

