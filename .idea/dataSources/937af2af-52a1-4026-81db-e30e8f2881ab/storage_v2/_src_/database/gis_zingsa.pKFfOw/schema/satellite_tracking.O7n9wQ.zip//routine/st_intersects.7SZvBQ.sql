create function st_intersects(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_Intersects($1::satellite_tracking.geometry, $2::satellite_tracking.geometry);  $$;

alter function st_intersects(text, text) owner to postgres;

