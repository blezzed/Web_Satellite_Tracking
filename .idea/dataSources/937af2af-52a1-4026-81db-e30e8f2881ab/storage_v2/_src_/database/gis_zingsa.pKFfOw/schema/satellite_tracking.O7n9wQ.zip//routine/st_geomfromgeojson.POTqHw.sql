create function st_geomfromgeojson(json) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking.ST_GeomFromGeoJson($1::text)$$;

alter function st_geomfromgeojson(json) owner to postgres;

