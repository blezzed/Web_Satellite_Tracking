create function st_voronoipolygons(g1 satellite_tracking.geometry, tolerance double precision DEFAULT 0.0, extend_to satellite_tracking.geometry DEFAULT NULL::satellite_tracking.geometry) returns satellite_tracking.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking._ST_Voronoi(g1, extend_to, tolerance, true) $$;

comment on function st_voronoipolygons(satellite_tracking.geometry, double precision, satellite_tracking.geometry) is 'args: geom, tolerance = 0.0, extend_to = NULL - Returns the cells of the Voronoi diagram of the vertices of a geometry.';

alter function st_voronoipolygons(satellite_tracking.geometry, double precision, satellite_tracking.geometry) owner to postgres;

