create function st_buffer(satellite_tracking.geography, double precision, integer) returns satellite_tracking.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT satellite_tracking.geography(satellite_tracking.ST_Transform(satellite_tracking.ST_Buffer(satellite_tracking.ST_Transform(satellite_tracking.geometry($1), satellite_tracking._ST_BestSRID($1)), $2, $3), satellite_tracking.ST_SRID($1)))$$;

comment on function st_buffer(satellite_tracking.geography, double precision, integer) is 'args: g1, radius_of_buffer, num_seg_quarter_circle - Computes a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(satellite_tracking.geography, double precision, integer) owner to postgres;

