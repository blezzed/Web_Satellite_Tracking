create function st_asgeojson(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT satellite_tracking.ST_AsGeoJson($1::satellite_tracking.geometry, 9, 0);  $$;

alter function st_asgeojson(text) owner to postgres;

