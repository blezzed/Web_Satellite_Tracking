create function st_assvg(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT satellite_tracking.ST_AsSVG($1::satellite_tracking.geometry,0,15);  $$;

alter function st_assvg(text) owner to postgres;

