create function st_isvalid(satellite_tracking.geometry, integer) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT (satellite_tracking.ST_isValidDetail($1, $2)).valid$$;

comment on function st_isvalid(satellite_tracking.geometry, integer) is 'args: g, flags - Tests if a geometry is well-formed in 2D.';

alter function st_isvalid(satellite_tracking.geometry, integer) owner to postgres;

