create function st_geomfromwkb(bytea, integer) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT satellite_tracking.ST_SetSRID(satellite_tracking.ST_GeomFromWKB($1), $2)$$;

alter function st_geomfromwkb(bytea, integer) owner to postgres;

