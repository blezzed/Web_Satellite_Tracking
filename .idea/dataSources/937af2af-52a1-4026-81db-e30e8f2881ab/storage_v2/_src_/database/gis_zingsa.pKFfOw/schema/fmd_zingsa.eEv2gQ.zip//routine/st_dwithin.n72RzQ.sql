create function st_dwithin(text, text, double precision) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT topology.ST_DWithin($1::topology.geometry, $2::topology.geometry, $3);  $$;

alter function st_dwithin(text, text, double precision) owner to postgres;

