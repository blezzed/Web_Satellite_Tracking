create function st_buffer(satellite_tracking.geography, double precision) returns satellite_tracking.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT satellite_tracking.geography(satellite_tracking.ST_Transform(satellite_tracking.ST_Buffer(satellite_tracking.ST_Transform(satellite_tracking.geometry($1), satellite_tracking._ST_BestSRID($1)), $2), satellite_tracking.ST_SRID($1)))$$;

alter function st_buffer(satellite_tracking.geography, double precision) owner to postgres;

