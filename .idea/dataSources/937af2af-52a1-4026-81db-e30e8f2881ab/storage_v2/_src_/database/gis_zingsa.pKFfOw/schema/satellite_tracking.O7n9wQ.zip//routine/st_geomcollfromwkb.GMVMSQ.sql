create function st_geomcollfromwkb(bytea, integer) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE
	WHEN satellite_tracking.geometrytype(satellite_tracking.ST_GeomFromWKB($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN satellite_tracking.ST_GeomFromWKB($1, $2)
	ELSE NULL END
	$$;

alter function st_geomcollfromwkb(bytea, integer) owner to postgres;

