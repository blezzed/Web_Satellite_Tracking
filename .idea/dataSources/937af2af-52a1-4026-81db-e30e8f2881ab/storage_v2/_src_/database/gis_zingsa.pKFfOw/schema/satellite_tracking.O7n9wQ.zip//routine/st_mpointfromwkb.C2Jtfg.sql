create function st_mpointfromwkb(bytea) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN satellite_tracking.geometrytype(satellite_tracking.ST_GeomFromWKB($1)) = 'MULTIPOINT'
	THEN satellite_tracking.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_mpointfromwkb(bytea) owner to postgres;

