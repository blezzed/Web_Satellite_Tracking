create function st_buffer(satellite_tracking.geography, double precision, text) returns satellite_tracking.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT satellite_tracking.geography(satellite_tracking.ST_Transform(satellite_tracking.ST_Buffer(satellite_tracking.ST_Transform(satellite_tracking.geometry($1), satellite_tracking._ST_BestSRID($1)), $2, $3), satellite_tracking.ST_SRID($1)))$$;

comment on function st_buffer(satellite_tracking.geography, double precision, text) is 'args: g1, radius_of_buffer, buffer_style_parameters - Computes a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(satellite_tracking.geography, double precision, text) owner to postgres;

