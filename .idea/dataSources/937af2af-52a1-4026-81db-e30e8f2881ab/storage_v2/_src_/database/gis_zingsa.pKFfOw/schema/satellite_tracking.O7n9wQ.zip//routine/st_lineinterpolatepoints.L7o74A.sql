create function st_lineinterpolatepoints(text, double precision) returns satellite_tracking.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_LineInterpolatePoints($1::satellite_tracking.geometry, $2);  $$;

alter function st_lineinterpolatepoints(text, double precision) owner to postgres;

