create function st_geomfromgeojson(jsonb) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking.ST_GeomFromGeoJson($1::text)$$;

alter function st_geomfromgeojson(jsonb) owner to postgres;

