create function st_shortestline(text, text) returns satellite_tracking.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_ShortestLine($1::satellite_tracking.geometry, $2::satellite_tracking.geometry);  $$;

alter function st_shortestline(text, text) owner to postgres;

