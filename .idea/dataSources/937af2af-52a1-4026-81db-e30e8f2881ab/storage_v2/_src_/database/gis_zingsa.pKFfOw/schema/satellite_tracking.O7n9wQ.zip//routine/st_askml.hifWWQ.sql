create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT satellite_tracking.ST_AsKML($1::satellite_tracking.geometry, 15);  $$;

alter function st_askml(text) owner to postgres;

