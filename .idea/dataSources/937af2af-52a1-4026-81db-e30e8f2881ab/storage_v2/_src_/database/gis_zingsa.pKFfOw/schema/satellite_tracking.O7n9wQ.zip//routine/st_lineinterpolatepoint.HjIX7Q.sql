create function st_lineinterpolatepoint(text, double precision) returns satellite_tracking.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_LineInterpolatePoint($1::satellite_tracking.geometry, $2);  $$;

alter function st_lineinterpolatepoint(text, double precision) owner to postgres;

