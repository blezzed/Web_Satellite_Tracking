create function st_intersects(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT topology.ST_Intersects($1::topology.geometry, $2::topology.geometry);  $$;

alter function st_intersects(text, text) owner to postgres;

