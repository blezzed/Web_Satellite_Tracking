create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT topology.ST_Distance($1::topology.geometry, $2::topology.geometry);  $$;

alter function st_distance(text, text) owner to postgres;

