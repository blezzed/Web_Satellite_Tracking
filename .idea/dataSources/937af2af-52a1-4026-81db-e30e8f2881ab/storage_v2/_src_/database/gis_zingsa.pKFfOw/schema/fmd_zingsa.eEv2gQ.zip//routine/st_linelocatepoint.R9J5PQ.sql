create function st_linelocatepoint(text, text) returns double precision
    immutable
    parallel safe
    language sql
as
$$ SELECT topology.ST_LineLocatePoint($1::topology.geometry, $2::topology.geometry);  $$;

alter function st_linelocatepoint(text, text) owner to postgres;

