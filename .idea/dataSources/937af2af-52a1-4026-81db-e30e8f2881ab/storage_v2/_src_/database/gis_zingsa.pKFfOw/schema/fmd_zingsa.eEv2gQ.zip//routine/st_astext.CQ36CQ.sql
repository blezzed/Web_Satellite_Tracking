create function st_astext(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT topology.ST_AsText($1::topology.geometry);  $$;

alter function st_astext(text) owner to postgres;

