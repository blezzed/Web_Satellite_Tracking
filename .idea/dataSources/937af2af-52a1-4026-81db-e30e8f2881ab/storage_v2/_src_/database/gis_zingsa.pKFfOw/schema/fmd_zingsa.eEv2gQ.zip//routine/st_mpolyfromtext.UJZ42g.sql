create function st_mpolyfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE WHEN topology.geometrytype(topology.ST_GeomFromText($1, $2)) = 'MULTIPOLYGON'
	THEN topology.ST_GeomFromText($1,$2)
	ELSE NULL END
	$$;

alter function st_mpolyfromtext(text, integer) owner to postgres;

