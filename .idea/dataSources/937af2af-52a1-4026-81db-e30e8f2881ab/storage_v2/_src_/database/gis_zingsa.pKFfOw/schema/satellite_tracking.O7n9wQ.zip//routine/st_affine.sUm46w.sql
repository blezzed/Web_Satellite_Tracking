create function st_affine(satellite_tracking.geometry, double precision, double precision, double precision, double precision, double precision, double precision) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT satellite_tracking.ST_Affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)$$;

comment on function st_affine(satellite_tracking.geometry, double precision, double precision, double precision, double precision, double precision, double precision) is 'args: geomA, a, b, d, e, xoff, yoff - Apply a 3D affine transformation to a geometry.';

alter function st_affine(satellite_tracking.geometry, double precision, double precision, double precision, double precision, double precision, double precision) owner to postgres;

