create function st_multilinestringfromtext(text, integer) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking.ST_MLineFromText($1, $2)$$;

alter function st_multilinestringfromtext(text, integer) owner to postgres;

