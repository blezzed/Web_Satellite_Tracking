create function _st_distanceuncached(satellite_tracking.geography, satellite_tracking.geography) returns double precision
    immutable
    strict
    language sql
as
$$SELECT satellite_tracking._ST_DistanceUnCached($1, $2, 0.0, true)$$;

alter function _st_distanceuncached(satellite_tracking.geography, satellite_tracking.geography) owner to postgres;

