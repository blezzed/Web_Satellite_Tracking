create function st_geomcollfromtext(text, integer) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE
	WHEN satellite_tracking.geometrytype(satellite_tracking.ST_GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN satellite_tracking.ST_GeomFromText($1,$2)
	ELSE NULL END
	$$;

alter function st_geomcollfromtext(text, integer) owner to postgres;

