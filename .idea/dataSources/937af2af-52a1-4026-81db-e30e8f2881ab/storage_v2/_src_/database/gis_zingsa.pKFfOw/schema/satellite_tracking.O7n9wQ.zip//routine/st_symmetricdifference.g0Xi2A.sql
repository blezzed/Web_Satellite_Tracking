create function st_symmetricdifference(geom1 satellite_tracking.geometry, geom2 satellite_tracking.geometry) returns satellite_tracking.geometry
    language sql
as
$$SELECT ST_SymDifference(geom1, geom2, -1.0);$$;

alter function st_symmetricdifference(satellite_tracking.geometry, satellite_tracking.geometry) owner to postgres;

