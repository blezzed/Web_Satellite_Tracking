create function st_mlinefromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE WHEN topology.geometrytype(topology.ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN topology.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_mlinefromtext(text) owner to postgres;

