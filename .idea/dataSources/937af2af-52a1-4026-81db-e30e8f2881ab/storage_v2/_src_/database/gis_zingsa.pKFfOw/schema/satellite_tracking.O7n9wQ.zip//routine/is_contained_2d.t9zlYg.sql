create function is_contained_2d(satellite_tracking.geometry, satellite_tracking.box2df) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(satellite_tracking.~) $1;$$;

alter function is_contained_2d(satellite_tracking.geometry, satellite_tracking.box2df) owner to postgres;

