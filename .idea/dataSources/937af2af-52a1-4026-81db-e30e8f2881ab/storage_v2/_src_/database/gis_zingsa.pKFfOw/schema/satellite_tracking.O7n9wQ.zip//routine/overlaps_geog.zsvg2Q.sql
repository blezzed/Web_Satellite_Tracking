create function overlaps_geog(satellite_tracking.geography, satellite_tracking.gidx) returns boolean
    immutable
    strict
    language sql
as
$$SELECT $2 OPERATOR(satellite_tracking.&&) $1;$$;

alter function overlaps_geog(satellite_tracking.geography, satellite_tracking.gidx) owner to postgres;

