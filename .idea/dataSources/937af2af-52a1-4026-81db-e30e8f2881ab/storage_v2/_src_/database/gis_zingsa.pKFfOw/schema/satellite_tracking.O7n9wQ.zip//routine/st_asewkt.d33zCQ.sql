create function st_asewkt(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT satellite_tracking.ST_AsEWKT($1::satellite_tracking.geometry);  $$;

alter function st_asewkt(text) owner to postgres;

