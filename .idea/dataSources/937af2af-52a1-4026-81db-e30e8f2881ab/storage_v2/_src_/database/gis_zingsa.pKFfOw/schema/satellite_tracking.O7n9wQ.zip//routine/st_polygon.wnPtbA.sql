create function st_polygon(satellite_tracking.geometry, integer) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT satellite_tracking.ST_SetSRID(satellite_tracking.ST_MakePolygon($1), $2)
	$$;

comment on function st_polygon(satellite_tracking.geometry, integer) is 'args: lineString, srid - Creates a Polygon from a LineString with a specified SRID.';

alter function st_polygon(satellite_tracking.geometry, integer) owner to postgres;

