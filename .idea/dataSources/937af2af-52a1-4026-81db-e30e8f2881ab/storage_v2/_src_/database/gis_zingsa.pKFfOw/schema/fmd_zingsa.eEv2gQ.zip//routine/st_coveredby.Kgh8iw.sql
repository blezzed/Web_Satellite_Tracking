create function st_coveredby(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT topology.ST_CoveredBy($1::topology.geometry, $2::topology.geometry);  $$;

alter function st_coveredby(text, text) owner to postgres;

