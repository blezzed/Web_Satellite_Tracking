create function st_buffer(text, double precision) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_Buffer($1::satellite_tracking.geometry, $2);  $$;

alter function st_buffer(text, double precision) owner to postgres;

