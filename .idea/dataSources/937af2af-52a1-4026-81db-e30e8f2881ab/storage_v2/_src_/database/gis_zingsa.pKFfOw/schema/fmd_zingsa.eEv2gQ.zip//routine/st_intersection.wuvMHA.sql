create function st_intersection(geography, geography) returns geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT topology.geography(topology.ST_Transform(topology.ST_Intersection(topology.ST_Transform(topology.geometry($1), topology._ST_BestSRID($1, $2)), topology.ST_Transform(topology.geometry($2), topology._ST_BestSRID($1, $2))), topology.ST_SRID($1)))$$;

comment on function st_intersection(geography, geography) is 'args: geogA, geogB - Computes a geometry representing the shared portion of geometries A and B.';

alter function st_intersection(geography, geography) owner to postgres;

