create function st_rotatez(satellite_tracking.geometry, double precision) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT satellite_tracking.ST_Rotate($1, $2)$$;

comment on function st_rotatez(satellite_tracking.geometry, double precision) is 'args: geomA, rotRadians - Rotates a geometry about the Z axis.';

alter function st_rotatez(satellite_tracking.geometry, double precision) owner to postgres;

