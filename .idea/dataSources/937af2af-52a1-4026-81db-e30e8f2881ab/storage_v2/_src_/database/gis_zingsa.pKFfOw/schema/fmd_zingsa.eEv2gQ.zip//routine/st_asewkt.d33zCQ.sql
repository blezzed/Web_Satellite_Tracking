create function st_asewkt(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT topology.ST_AsEWKT($1::topology.geometry);  $$;

alter function st_asewkt(text) owner to postgres;

