create function st_maxdistance(geom1 satellite_tracking.geometry, geom2 satellite_tracking.geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT satellite_tracking._ST_MaxDistance(satellite_tracking.ST_ConvexHull($1), satellite_tracking.ST_ConvexHull($2))$$;

comment on function st_maxdistance(satellite_tracking.geometry, satellite_tracking.geometry) is 'args: g1, g2 - Returns the 2D largest distance between two geometries in projected units.';

alter function st_maxdistance(satellite_tracking.geometry, satellite_tracking.geometry) owner to postgres;

