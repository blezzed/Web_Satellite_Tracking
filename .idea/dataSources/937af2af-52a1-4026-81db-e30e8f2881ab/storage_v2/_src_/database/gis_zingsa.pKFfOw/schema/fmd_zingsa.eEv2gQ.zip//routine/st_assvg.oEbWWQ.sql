create function st_assvg(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT topology.ST_AsSVG($1::topology.geometry,0,15);  $$;

alter function st_assvg(text) owner to postgres;

