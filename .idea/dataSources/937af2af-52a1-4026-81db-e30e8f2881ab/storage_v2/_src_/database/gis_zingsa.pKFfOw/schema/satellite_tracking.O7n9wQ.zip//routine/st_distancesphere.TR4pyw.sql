create function st_distancesphere(geom1 satellite_tracking.geometry, geom2 satellite_tracking.geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$select satellite_tracking.ST_distance( satellite_tracking.geography($1), satellite_tracking.geography($2),false)$$;

alter function st_distancesphere(satellite_tracking.geometry, satellite_tracking.geometry) owner to postgres;

