create function st_geomcollfromtext(text) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE
	WHEN satellite_tracking.geometrytype(satellite_tracking.ST_GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN satellite_tracking.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_geomcollfromtext(text) owner to postgres;

