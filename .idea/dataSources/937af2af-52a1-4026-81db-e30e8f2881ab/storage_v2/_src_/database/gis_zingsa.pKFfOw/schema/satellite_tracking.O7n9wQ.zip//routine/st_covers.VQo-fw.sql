create function st_covers(text, text) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_Covers($1::satellite_tracking.geometry, $2::satellite_tracking.geometry);  $$;

alter function st_covers(text, text) owner to postgres;

