create function st_astext(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT satellite_tracking.ST_AsText($1::satellite_tracking.geometry);  $$;

alter function st_astext(text) owner to postgres;

