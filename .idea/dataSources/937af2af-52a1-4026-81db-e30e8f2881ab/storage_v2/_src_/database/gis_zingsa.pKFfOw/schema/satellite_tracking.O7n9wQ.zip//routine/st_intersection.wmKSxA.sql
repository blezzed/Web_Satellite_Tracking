create function st_intersection(text, text) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$ SELECT satellite_tracking.ST_Intersection($1::satellite_tracking.geometry, $2::satellite_tracking.geometry);  $$;

alter function st_intersection(text, text) owner to postgres;

