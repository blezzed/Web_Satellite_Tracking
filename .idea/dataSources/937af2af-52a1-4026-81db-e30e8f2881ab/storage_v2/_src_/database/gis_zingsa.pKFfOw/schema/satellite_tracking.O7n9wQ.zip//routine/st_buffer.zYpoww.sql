create function st_buffer(text, double precision, integer) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_Buffer($1::satellite_tracking.geometry, $2, $3);  $$;

alter function st_buffer(text, double precision, integer) owner to postgres;

