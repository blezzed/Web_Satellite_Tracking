create function st_geomfromgml(text) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking._ST_GeomFromGML($1, 0)$$;

alter function st_geomfromgml(text) owner to postgres;

