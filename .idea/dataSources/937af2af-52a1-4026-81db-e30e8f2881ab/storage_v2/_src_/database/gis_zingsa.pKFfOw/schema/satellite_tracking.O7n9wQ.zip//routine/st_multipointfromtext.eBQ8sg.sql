create function st_multipointfromtext(text) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking.ST_MPointFromText($1)$$;

alter function st_multipointfromtext(text) owner to postgres;

