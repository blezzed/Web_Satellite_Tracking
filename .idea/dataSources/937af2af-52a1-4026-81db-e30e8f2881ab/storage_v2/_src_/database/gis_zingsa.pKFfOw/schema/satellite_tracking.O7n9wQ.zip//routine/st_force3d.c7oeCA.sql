create function st_force3d(geom satellite_tracking.geometry, zvalue double precision DEFAULT 0.0) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT satellite_tracking.ST_Force3DZ($1, $2)$$;

comment on function st_force3d(satellite_tracking.geometry, double precision) is 'args: geomA, Zvalue = 0.0 - Force the geometries into XYZ mode. This is an alias for ST_Force3DZ.';

alter function st_force3d(satellite_tracking.geometry, double precision) owner to postgres;

