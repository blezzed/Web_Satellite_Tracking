create function st_intersection(satellite_tracking.geography, satellite_tracking.geography) returns satellite_tracking.geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT satellite_tracking.geography(satellite_tracking.ST_Transform(satellite_tracking.ST_Intersection(satellite_tracking.ST_Transform(satellite_tracking.geometry($1), satellite_tracking._ST_BestSRID($1, $2)), satellite_tracking.ST_Transform(satellite_tracking.geometry($2), satellite_tracking._ST_BestSRID($1, $2))), satellite_tracking.ST_SRID($1)))$$;

comment on function st_intersection(satellite_tracking.geography, satellite_tracking.geography) is 'args: geogA, geogB - Computes a geometry representing the shared portion of geometries A and B.';

alter function st_intersection(satellite_tracking.geography, satellite_tracking.geography) owner to postgres;

