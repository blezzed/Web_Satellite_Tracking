create function st_closestpoint(text, text) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT topology.ST_ClosestPoint($1::topology.geometry, $2::topology.geometry);  $$;

alter function st_closestpoint(text, text) owner to postgres;

