create function overlaps_nd(satellite_tracking.geometry, satellite_tracking.gidx) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(satellite_tracking.&&&) $1;$$;

alter function overlaps_nd(satellite_tracking.geometry, satellite_tracking.gidx) owner to postgres;

