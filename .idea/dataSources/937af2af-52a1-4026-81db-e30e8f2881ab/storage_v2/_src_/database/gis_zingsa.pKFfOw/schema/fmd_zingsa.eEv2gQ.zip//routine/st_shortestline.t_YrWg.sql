create function st_shortestline(text, text) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT topology.ST_ShortestLine($1::topology.geometry, $2::topology.geometry);  $$;

alter function st_shortestline(text, text) owner to postgres;

