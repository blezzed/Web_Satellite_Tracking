create function st_length(text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_Length($1::satellite_tracking.geometry);  $$;

alter function st_length(text) owner to postgres;

