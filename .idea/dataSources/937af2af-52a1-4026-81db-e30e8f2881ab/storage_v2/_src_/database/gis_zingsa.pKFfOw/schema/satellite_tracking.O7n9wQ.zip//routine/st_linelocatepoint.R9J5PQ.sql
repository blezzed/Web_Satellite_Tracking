create function st_linelocatepoint(text, text) returns double precision
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_LineLocatePoint($1::satellite_tracking.geometry, $2::satellite_tracking.geometry);  $$;

alter function st_linelocatepoint(text, text) owner to postgres;

