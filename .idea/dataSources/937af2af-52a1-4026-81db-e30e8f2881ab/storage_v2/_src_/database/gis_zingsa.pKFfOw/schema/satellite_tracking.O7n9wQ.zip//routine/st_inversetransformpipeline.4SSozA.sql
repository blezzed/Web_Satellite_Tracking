create function st_inversetransformpipeline(geom satellite_tracking.geometry, pipeline text, to_srid integer DEFAULT 0) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT satellite_tracking.postgis_transform_pipeline_geometry($1, $2, FALSE, $3)$$;

comment on function st_inversetransformpipeline(satellite_tracking.geometry, text, integer) is 'args: geom, pipeline, to_srid - Return a new geometry with coordinates transformed to a different spatial reference system using the inverse of a defined coordinate transformation pipeline.';

alter function st_inversetransformpipeline(satellite_tracking.geometry, text, integer) owner to postgres;

