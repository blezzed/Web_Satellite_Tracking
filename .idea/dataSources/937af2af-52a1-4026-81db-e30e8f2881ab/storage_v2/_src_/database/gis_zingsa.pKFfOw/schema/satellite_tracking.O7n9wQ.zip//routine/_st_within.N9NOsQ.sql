create function _st_within(geom1 satellite_tracking.geometry, geom2 satellite_tracking.geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$SELECT satellite_tracking._ST_Contains($2,$1)$$;

alter function _st_within(satellite_tracking.geometry, satellite_tracking.geometry) owner to postgres;

