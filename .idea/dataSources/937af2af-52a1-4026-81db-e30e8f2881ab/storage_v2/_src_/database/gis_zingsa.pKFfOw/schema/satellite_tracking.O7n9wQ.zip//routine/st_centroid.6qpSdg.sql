create function st_centroid(text) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_Centroid($1::satellite_tracking.geometry);  $$;

alter function st_centroid(text) owner to postgres;

