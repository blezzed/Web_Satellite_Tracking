create function st_polygonfromtext(text) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking.ST_PolyFromText($1)$$;

alter function st_polygonfromtext(text) owner to postgres;

