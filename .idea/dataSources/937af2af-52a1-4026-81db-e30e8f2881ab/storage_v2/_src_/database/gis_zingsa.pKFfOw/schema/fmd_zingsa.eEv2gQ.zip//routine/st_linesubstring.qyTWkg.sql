create function st_linesubstring(text, double precision, double precision) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT topology.ST_LineSubstring($1::topology.geometry, $2, $3);  $$;

alter function st_linesubstring(text, double precision, double precision) owner to postgres;

