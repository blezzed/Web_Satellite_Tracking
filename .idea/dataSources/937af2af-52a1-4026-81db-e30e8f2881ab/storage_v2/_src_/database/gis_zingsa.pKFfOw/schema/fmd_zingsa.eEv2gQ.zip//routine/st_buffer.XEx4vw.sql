create function st_buffer(geography, double precision) returns geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT topology.geography(topology.ST_Transform(topology.ST_Buffer(topology.ST_Transform(topology.geometry($1), topology._ST_BestSRID($1)), $2), topology.ST_SRID($1)))$$;

alter function st_buffer(geography, double precision) owner to postgres;

