create function st_buffer(text, double precision, text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT topology.ST_Buffer($1::topology.geometry, $2, $3);  $$;

alter function st_buffer(text, double precision, text) owner to postgres;

