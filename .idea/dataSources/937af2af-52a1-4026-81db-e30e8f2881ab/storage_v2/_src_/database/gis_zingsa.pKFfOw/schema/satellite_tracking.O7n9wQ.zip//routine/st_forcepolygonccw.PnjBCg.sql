create function st_forcepolygonccw(satellite_tracking.geometry) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$ SELECT satellite_tracking.ST_Reverse(satellite_tracking.ST_ForcePolygonCW($1)) $$;

comment on function st_forcepolygonccw(satellite_tracking.geometry) is 'args: geom - Orients all exterior rings counter-clockwise and all interior rings clockwise.';

alter function st_forcepolygonccw(satellite_tracking.geometry) owner to postgres;

