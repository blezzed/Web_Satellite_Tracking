create function st_linesubstring(text, double precision, double precision) returns satellite_tracking.geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_LineSubstring($1::satellite_tracking.geometry, $2, $3);  $$;

alter function st_linesubstring(text, double precision, double precision) owner to postgres;

