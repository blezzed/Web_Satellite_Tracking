create function st_pointfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE WHEN topology.geometrytype(topology.ST_GeomFromText($1)) = 'POINT'
	THEN topology.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_pointfromtext(text) owner to postgres;

