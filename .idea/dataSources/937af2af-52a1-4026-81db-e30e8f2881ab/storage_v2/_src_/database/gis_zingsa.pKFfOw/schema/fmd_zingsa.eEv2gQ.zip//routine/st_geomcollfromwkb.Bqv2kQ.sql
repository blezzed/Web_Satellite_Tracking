create function st_geomcollfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE
	WHEN topology.geometrytype(topology.ST_GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN topology.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_geomcollfromwkb(bytea) owner to postgres;

