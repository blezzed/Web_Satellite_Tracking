create function st_multipolygonfromtext(text, integer) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking.ST_MPolyFromText($1, $2)$$;

alter function st_multipolygonfromtext(text, integer) owner to postgres;

