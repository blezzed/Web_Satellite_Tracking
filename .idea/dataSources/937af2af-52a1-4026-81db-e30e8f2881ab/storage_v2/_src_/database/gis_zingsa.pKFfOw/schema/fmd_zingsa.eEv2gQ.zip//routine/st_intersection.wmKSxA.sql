create function st_intersection(text, text) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$ SELECT topology.ST_Intersection($1::topology.geometry, $2::topology.geometry);  $$;

alter function st_intersection(text, text) owner to postgres;

