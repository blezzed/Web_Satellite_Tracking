create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT satellite_tracking.ST_Distance($1::satellite_tracking.geometry, $2::satellite_tracking.geometry);  $$;

alter function st_distance(text, text) owner to postgres;

