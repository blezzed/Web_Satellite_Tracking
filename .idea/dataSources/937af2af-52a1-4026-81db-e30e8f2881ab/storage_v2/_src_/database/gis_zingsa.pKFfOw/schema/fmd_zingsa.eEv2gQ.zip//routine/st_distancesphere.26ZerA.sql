create function st_distancesphere(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$select topology.ST_distance( topology.geography($1), topology.geography($2),false)$$;

alter function st_distancesphere(geometry, geometry) owner to postgres;

