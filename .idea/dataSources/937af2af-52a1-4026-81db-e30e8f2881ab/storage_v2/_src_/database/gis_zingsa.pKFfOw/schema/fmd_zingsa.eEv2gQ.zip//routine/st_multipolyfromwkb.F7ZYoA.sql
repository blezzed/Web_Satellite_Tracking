create function st_multipolyfromwkb(bytea, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT CASE WHEN topology.geometrytype(topology.ST_GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN topology.ST_GeomFromWKB($1, $2)
	ELSE NULL END
	$$;

alter function st_multipolyfromwkb(bytea, integer) owner to postgres;

