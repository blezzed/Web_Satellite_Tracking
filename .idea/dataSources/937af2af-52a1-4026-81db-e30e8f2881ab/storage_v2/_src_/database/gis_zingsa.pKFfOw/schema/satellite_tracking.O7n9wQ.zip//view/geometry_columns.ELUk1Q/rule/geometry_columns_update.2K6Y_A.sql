CREATE RULE geometry_columns_update AS
    ON UPDATE TO satellite_tracking.geometry_columns DO INSTEAD NOTHING;

