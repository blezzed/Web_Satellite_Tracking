create function st_gmltosql(text) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT satellite_tracking._ST_GeomFromGML($1, 0)$$;

alter function st_gmltosql(text) owner to postgres;

