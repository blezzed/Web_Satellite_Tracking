create function _st_distanceuncached(satellite_tracking.geography, satellite_tracking.geography, boolean) returns double precision
    immutable
    strict
    language sql
as
$$SELECT satellite_tracking._ST_DistanceUnCached($1, $2, 0.0, $3)$$;

alter function _st_distanceuncached(satellite_tracking.geography, satellite_tracking.geography, boolean) owner to postgres;

