create function st_longestline(geom1 satellite_tracking.geometry, geom2 satellite_tracking.geometry) returns satellite_tracking.geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT satellite_tracking._ST_LongestLine(satellite_tracking.ST_ConvexHull($1), satellite_tracking.ST_ConvexHull($2))$$;

comment on function st_longestline(satellite_tracking.geometry, satellite_tracking.geometry) is 'args: g1, g2 - Returns the 2D longest line between two geometries.';

alter function st_longestline(satellite_tracking.geometry, satellite_tracking.geometry) owner to postgres;

